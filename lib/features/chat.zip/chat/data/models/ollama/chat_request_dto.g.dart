// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'chat_request_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ChatRequestDto _$ChatRequestDtoFromJson(Map<String, dynamic> json) =>
    ChatRequestDto(
      model: json['model'] as String,
      messages: (json['messages'] as List<dynamic>)
          .map((e) => MessageDto.fromJson(e as Map<String, dynamic>))
          .toList(),
      stream: json['stream'] as bool? ?? false,
    );

Map<String, dynamic> _$ChatRequestDtoToJson(ChatRequestDto instance) =>
    <String, dynamic>{
      'model': instance.model,
      'messages': instance.messages,
      'stream': instance.stream,
    };
