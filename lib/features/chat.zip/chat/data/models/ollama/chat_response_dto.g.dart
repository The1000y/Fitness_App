// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'chat_response_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ChatResponseDto _$ChatResponseDtoFromJson(Map<String, dynamic> json) =>
    ChatResponseDto(
      model: json['model'] as String?,
      message: json['message'] == null
          ? null
          : MessageDto.fromJson(json['message'] as Map<String, dynamic>),
      done: json['done'] as bool?,
    );

Map<String, dynamic> _$ChatResponseDtoToJson(ChatResponseDto instance) =>
    <String, dynamic>{
      'model': instance.model,
      'message': instance.message,
      'done': instance.done,
    };
