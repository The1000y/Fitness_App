
import 'package:fitness_app/features/chat/data/models/firestore/chat_model.dart';
import 'package:fitness_app/features/chat/data/models/firestore/message_model.dart';

abstract interface class ChatFirestoreDataSource {
  Future<ChatModel> createChat({
    required String title,
  });

  Future<List<ChatModel>> getChats();

  Future<void> deleteChat({
    required String chatId,
  });

  Future<MessageModel> saveMessage({
    required String chatId,
    required String content,
    required String role,
  });

  Future<List<MessageModel>> getChatHistory({
    required String chatId,
  });
}
